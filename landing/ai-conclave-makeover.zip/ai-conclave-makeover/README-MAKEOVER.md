# The AI Conclave aesthetic overhaul

This package keeps your existing page structure and content, but adds a new late-loading stylesheet: `overhaul.css`.

Files changed:

- `index.html`
- `how-it-works.html`
- `use-cases.html`
- `pricing.html`
- `manifesto.html`

Each HTML file now loads `overhaul.css` after its page-level inline CSS. That matters because the original pages contain large inline style blocks. A normal replacement of `styles.css` alone would not fully override them.

Design direction:

- Brighter AI command-center look
- Glassmorphism panels
- Neon cyan, violet, gold, and emerald accents
- Bigger rounded cards
- Stronger contrast
- Cleaner navigation
- Less muddy black-on-black density
- More modern SaaS/product feel

Keep both `styles.css` and `overhaul.css` together in the same folder.
